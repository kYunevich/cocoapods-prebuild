//
// Project «InputMask»
// Created by Jeorge Taflanidi
//

#import <UIKit/UIKit.h>

//! Project version number for InputMask.
FOUNDATION_EXPORT double InputMaskVersionNumber;

//! Project version string for InputMask.
FOUNDATION_EXPORT const unsigned char InputMaskVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InputMask/PublicHeader.h>


