//
//  NSHTTPURLResponse+MaxAge.m
//
//  Created by Kevin Smith on 6/15/18.
//
//

#import <Foundation/Foundation.h>

@interface NSHTTPURLResponse (MaxAge)
  
- (NSNumber *)findMaxAge;

@end
