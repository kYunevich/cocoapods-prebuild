//
//  PINAnimatedImageView+PINRemoteImage.h
//  Pods
//
//  Created by Garrett Moon on 4/19/18.
//

#import "PINAnimatedImageView.h"

#import "PINRemoteImageCategoryManager.h"

@interface PINAnimatedImageView (PINRemoteImage) <PINRemoteImageCategory>

@end
